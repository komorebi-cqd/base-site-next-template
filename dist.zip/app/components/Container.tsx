import React from 'react'

const Container = () => {
  return (
    <div>Container</div>
  )
}

export default Container