export type SafeUser = {
  imgUrl: string;
  username: string;
  id: number;
};
